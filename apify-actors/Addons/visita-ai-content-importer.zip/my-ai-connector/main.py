import requests
import json
from apify import Actor

async def main():
    async with Actor() as actor:
        # Get Input
        actor_input = await actor.get_input() or {}
        site_url = actor_input.get('site_url')
        secret_key = actor_input.get('app_password') # Reusing this field for the Secret Key
        action = actor_input.get('action')
        data_string = actor_input.get('data')

        if not site_url or not secret_key or not action:
            actor.log.error("Missing inputs.")
            await actor.fail()
            return

        # Parse the JSON payload
        try:
            payload_data = json.loads(data_string)
        except json.JSONDecodeError:
            actor.log.error("Invalid JSON in data field.")
            await actor.fail()
            return

        # Prepare the "Side Door" URL
        # We append /?my-ai-connector=1 to the root URL
        target_url = f"{site_url.rstrip('/')}/?my-ai-connector=1"

        # Prepare Headers
        headers = {
            "Authorization": f"Bearer {secret_key}",
            "Content-Type": "application/json",
            # Spoof User-Agent to bypass LiteSpeed Bot Check
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
        }

        # Prepare the Packet for the PHP Plugin
        request_body = {
            "action": action,
            "payload": payload_data
        }

        actor.log.info(f"Connecting via Plugin Side-Door: {target_url}")
        actor.log.info(f"Attempting Action: {action}")

        try:
            response = requests.post(target_url, json=request_body, headers=headers, timeout=30)
            
            # Check for the specific LiteSpeed HTML error again
            if "<title>Bot Verification</title>" in response.text:
                actor.log.error("Firewall still blocking. Try whitelisting the IP or using Apify Residential Proxy.")
                raise ValueError("Hosting Firewall Blocked Request")

            response.raise_for_status()
            
            result = response.json()
            
            if result.get('status') == 'error':
                actor.log.error(f"Plugin returned error: {result.get('message')}")
                await actor.fail()
            else:
                actor.log.info("Success!")
                await actor.push_data(result)

        except Exception as e:
            actor.log.error(f"Request Failed: {e}")
            if 'response' in locals():
                actor.log.error(f"Response Body: {response.text[:500]}") # Log first 500 chars
            await actor.fail()