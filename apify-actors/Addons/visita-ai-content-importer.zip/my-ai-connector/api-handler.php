<?php
// Get raw POST data
$json_input = file_get_contents('php://input');
$data = json_decode($json_input, true);

// 1. SECURITY: Check Secret Key
$headers = getallheaders();
$auth_header = isset($headers['Authorization']) ? $headers['Authorization'] : '';
$stored_key = get_option('mac_secret_key');

// Handle "Bearer sk_..." format
if (strpos($auth_header, 'Bearer ') === 0) {
    $auth_header = substr($auth_header, 7);
}

if (!$stored_key || $auth_header !== $stored_key) {
    status_header(403);
    echo json_encode(['error' => 'Invalid Secret Key']);
    exit;
}

// 2. ROUTER: Modular Action Handling
$action = isset($data['action']) ? $data['action'] : '';
$payload = isset($data['payload']) ? $data['payload'] : [];

$response = ['status' => 'error', 'message' => 'Unknown action'];

switch ($action) {
    // --- CORE WORDPRESS MODULE ---
    case 'create_post':
        $id = wp_insert_post($payload);
        if (is_wp_error($id)) {
            $response = ['status' => 'error', 'message' => $id->get_error_message()];
        } else {
            $response = ['status' => 'success', 'id' => $id, 'link' => get_permalink($id)];
        }
        break;

    case 'get_post':
        $post = get_post($payload['id']);
        $response = ['status' => 'success', 'data' => $post];
        break;

    // --- FUTURE MODULES (Example) ---
    // case 'update_acf':
    //      update_field($payload['field_key'], $payload['value'], $payload['post_id']);
    //      break;

    default:
        $response = ['status' => 'error', 'message' => "Action '$action' not supported."];
        break;
}

// 3. OUTPUT
header('Content-Type: application/json');
echo json_encode($response);